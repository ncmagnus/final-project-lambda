## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  library(ODTR), 
  library(SuperLearner),
  library(hitandrun)
)

## ------------------------------------------------------------------------
set.seed(37982)
data <- data.simulation(n=1000)
W = data[,grep("W", names(data))]
W_for_g = subset(W, select = c(W1, W2))
A = data$A
a = 0
Y = data$Y
rule = ifelse(data$W2 > 0, 1, 0) #for simple dynamic treatment 
QAW.SL.library = "SL.correct"
head(data)

## ------------------------------------------------------------------------
resultssimple = sdtr(W = W, W_for_g = W, a = a, A = A, Y = Y, 
                              rule = rule, 
                              QAW.SL.library = QAW.SL.library)
resultssimple

## ------------------------------------------------------------------------
# note V must contain W_for_g
V = subset(W, select = c(W1, W2))
grid.size = 100
risk.type = "empirical"
QAV.SL.library = c("SL.glm", "SL.glmnet", "SL.mean")
resultsODTR = odtr(W = W, A = A, a = a, Y = Y, V = V, W_for_g = W_for_g,
                          QAW.SL.library = QAW.SL.library, 
                          QAV.SL.library = QAV.SL.library,
                          risk.type = risk.type,
                          grid.size = grid.size)
resultsODTR

