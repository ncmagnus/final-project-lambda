## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  library(ODTR), 
  library(SuperLearner),
  library(hitandrun)
)

## ------------------------------------------------------------------------
set.seed(37982)
data <- data.simulation(n=100)
W = data[,grep("W", names(data))]
W_for_g = subset(W, select = c(W4))
A = data$A
a = 0
Y = data$Y
rule = data$A_star
QAW.SL.library = c("SL.glm", "SL.mean", "SL.glmnet")
resultssimple = sodtr(W = W, W_for_g = W, a = a, A = A, Y = Y, 
                              rule = rule, 
                              QAW.SL.library = QAW.SL.library)
resultssimple
resultssimple - mean(Y)

## ------------------------------------------------------------------------
# note V must contain W_for_g
V = subset(W, select = c(W1, W2, W4))
grid.size = 100
risk.type = "empirical"
QAV.SL.library = c("SL.glm", "SL.mean", "SL.glmnet","SL.xgboost")
QAW.SL.library = c("SL.glm", "SL.mean", "SL.glmnet")
resultsODTR = odtr(W = W, A = A, a = a, Y = Y, V = V, W_for_g = W_for_g,
                          QAW.SL.library = QAW.SL.library, 
                          QAV.SL.library = QAV.SL.library,
                          risk.type = risk.type,
                          grid.size = grid.size)
resultsODTR

